from azure.storage.blob import BlobServiceClient,BlobClient
import io
import pandas as pd

class Connector:
    def __init__(self) -> None:
        self.connection_string="DefaultEndpointsProtocol=https;AccountName=aneritrainingc339;AccountKey=TW0zW3Y/8FbgkLlUhrlKxu7Obr4jOD7M69y94VtMoIRUTAdKWxmztYcjn7NuU8HJytEDkMy4JoEd+AStkFBaSQ==;EndpointSuffix=core.windows.net"
        self.container_name="c339"

    def connect(self):
        self.blob_service_client= BlobServiceClient.from_connection_string(self.connection_string)

    def download_blob(self, file_path):
        blob_client = self.blob_service_client.get_blob_client(self.container_name, file_path)
        blob_data = blob_client.download_blob()
        data = blob_data.content_as_text()
        return data


my_connector = Connector()
my_connector.connect()
geo_data = my_connector.download_blob("grdc_river/geographicaldata.csv")
geo_data_df = pd.read_csv(io.StringIO(geo_data))
geo_data_df.head()

daily_data = my_connector.download_blob("grdc_river/daywisedata.csv")
daily_data_df = pd.read_csv(io.StringIO(daily_data))
daily_data_df.head()